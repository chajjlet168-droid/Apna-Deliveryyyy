package com.apnadelivery.app;

import android.os.Bundle;
import android.graphics.Color;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    FrameLayout content; LinearLayout page;
    ArrayList<String[]> products = new ArrayList<>();
    ArrayList<String[]> cart = new ArrayList<>();
    ArrayList<String> orders = new ArrayList<>();
    int yellow = Color.rgb(255,184,0), dark = Color.rgb(30,30,30);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        content=findViewById(R.id.content);
        seed();
        findViewById(R.id.navHome).setOnClickListener(v->home());
        findViewById(R.id.navOrders).setOnClickListener(v->orders());
        findViewById(R.id.navCart).setOnClickListener(v->cart());
        findViewById(R.id.navProfile).setOnClickListener(v->profile());
        login();
    }

    void seed(){
        products.add(new String[]{"🍛 Chicken Biryani","Food","149"});
        products.add(new String[]{"🍕 Pizza","Food","249"});
        products.add(new String[]{"🛒 Grocery Combo","Grocery","299"});
        products.add(new String[]{"🥛 Milk 1L","Grocery","62"});
        products.add(new String[]{"💊 Pharmacy Essentials","Pharmacy","199"});
        products.add(new String[]{"👕 Cotton T-Shirt","Fashion","399"});
        products.add(new String[]{"📦 Daily Essentials","Other","199"});
    }

    void clear(){ content.removeAllViews(); page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(18,18,18,12); ScrollView s=new ScrollView(this); s.addView(page); content.addView(s); }
    TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark); t.setPadding(8,12,8,12); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setAllCaps(false); return b; }
    void title(String s){ TextView t=text("🛵  "+s,28); t.setTextColor(yellow); t.setTypeface(null,1); page.addView(t); }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void login(){
        clear(); title("Apna Delivery");
        page.addView(text("Welcome back! Login to continue.",19));
        EditText mobile=new EditText(this); mobile.setHint("Mobile number"); mobile.setInputType(InputType.TYPE_CLASS_PHONE); page.addView(mobile);
        EditText pass=new EditText(this); pass.setHint("Password"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); page.addView(pass);
        Button l=button("LOGIN  →"); l.setBackgroundColor(yellow); page.addView(l);
        Button r=button("Create new account"); page.addView(r);
        l.setOnClickListener(v->home());
        r.setOnClickListener(v->register());
        page.addView(text("Login is local demo mode. Real OTP/SMS requires a backend.",13));
    }

    void register(){
        clear(); title("Create Account");
        EditText name=new EditText(this); name.setHint("Full name"); page.addView(name);
        EditText mobile=new EditText(this); mobile.setHint("Mobile number"); page.addView(mobile);
        EditText address=new EditText(this); address.setHint("Delivery address"); page.addView(address);
        EditText pass=new EditText(this); pass.setHint("Password"); pass.setInputType(129); page.addView(pass);
        Button b=button("REGISTER & CONTINUE"); page.addView(b); b.setOnClickListener(v->home());
        Button back=button("← Back to Login"); page.addView(back); back.setOnClickListener(v->login());
    }

    void home(){
        clear(); title("Home");
        page.addView(text("Fast delivery • Local shops • Easy ordering",16));
        EditText search=new EditText(this); search.setHint("🔍 Search products or shops"); page.addView(search);
        page.addView(text("Categories",24));
        String[] cats={"🍔 Food","🛒 Grocery","💊 Pharmacy","👕 Fashion","📦 Other"};
        for(String c:cats){ Button b=button(c); page.addView(b); b.setOnClickListener(v->category(c.substring(c.indexOf(" ")+1))); }
        page.addView(text("Popular near you",24));
        for(String[] p:products.subList(0,Math.min(4,products.size()))) product(p);
        search.setOnEditorActionListener((v,a,e)->{searchProducts(search.getText().toString());return true;});
    }

    void searchProducts(String q){
        clear(); title("Search");
        for(String[] p:products) if(p[0].toLowerCase().contains(q.toLowerCase())||p[1].toLowerCase().contains(q.toLowerCase())) product(p);
    }

    void category(String c){
        clear(); title(c);
        for(String[] p:products) if(p[1].equalsIgnoreCase(c.trim())) product(p);
    }

    void product(String[] p){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView info=text(p[0]+"\n₹"+p[2]+"  •  "+p[1],18); row.addView(info,new LinearLayout.LayoutParams(0,90,1));
        Button add=button("ADD"); row.addView(add); add.setOnClickListener(v->{cart.add(p);toast(p[0]+" added to cart");});
        page.addView(row);
    }

    void cart(){
        clear(); title("My Cart");
        if(cart.isEmpty()){page.addView(text("Your cart is empty.",20));return;}
        int total=0;
        for(String[] p:new ArrayList<>(cart)){
            total+=Integer.parseInt(p[2]); LinearLayout row=new LinearLayout(this);
            row.addView(text(p[0]+"  ₹"+p[2],18),new LinearLayout.LayoutParams(0,70,1));
            Button rm=button("Remove"); row.addView(rm); rm.setOnClickListener(v->{cart.remove(p);cart();}); page.addView(row);
        }
        page.addView(text("Total: ₹"+total,24));
        Button checkout=button("PROCEED TO CHECKOUT"); page.addView(checkout); checkout.setOnClickListener(v->checkout());
    }

    void checkout(){
        clear(); title("Checkout");
        EditText address=new EditText(this); address.setHint("📍 Delivery address"); page.addView(address);
        page.addView(text("Payment",22));
        RadioGroup g=new RadioGroup(this);
        RadioButton cod=new RadioButton(this); cod.setText("Cash on Delivery"); cod.setChecked(true);
        RadioButton online=new RadioButton(this); online.setText("Online Payment (demo)");
        g.addView(cod); g.addView(online); page.addView(g);
        Button place=button("PLACE ORDER"); page.addView(place);
        place.setOnClickListener(v->{if(address.getText().toString().trim().isEmpty()){address.setError("Address required");return;}
            orders.add("Order #AD"+(1000+orders.size()+1)+" • "+cart.size()+" item(s) • Preparing");
            cart.clear();toast("Order placed successfully");orders();});
    }

    void orders(){
        clear(); title("My Orders");
        if(orders.isEmpty()) page.addView(text("No orders yet.",20));
        for(String o:orders) page.addView(text("📦  "+o,18));
    }

    void profile(){
        clear(); title("Profile");
        page.addView(text("👤 Customer Account",22));
        page.addView(text("📍 Saved Address\n💳 Payment Methods\n🔔 Notifications\n❤️ Wishlist\n❓ Help & Support",18));
        Button logout=button("LOGOUT"); page.addView(logout); logout.setOnClickListener(v->login());
        Button admin=button("Admin / Vendor / Delivery Demo"); page.addView(admin); admin.setOnClickListener(v->dashboard());
    }

    void dashboard(){
        clear(); title("Business Dashboard");
        page.addView(text("🏪 Vendor • 🚚 Delivery Partner • ⚙️ Admin",20));
        page.addView(text("Orders today: "+orders.size(),18));
        page.addView(text("Earnings: ₹"+(orders.size()*149),18));
        page.addView(text("Delivery status: Ready for assignment",18));
        Button back=button("Back to Profile"); page.addView(back); back.setOnClickListener(v->profile());
    }
}
