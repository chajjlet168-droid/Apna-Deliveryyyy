# Apna Delivery — Full Featured Starter App

Android app project with branded launcher icon and working local flows:
- Login / Register
- Home and categories
- Product listing and add-to-cart
- Cart and place-order flow
- Orders history
- Profile and logout
- GitHub Actions workflow that builds a debug APK

This is a local/demo app. Live OTP, payment gateway, maps/GPS, shop/rider accounts and cloud database require backend/API credentials.
